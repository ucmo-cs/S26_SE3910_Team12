package com.example.bank.service;

import com.example.bank.model.Appointment;
import com.example.bank.repository.AppointmentRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {

    private final AppointmentRepository repo;

    public AppointmentService(AppointmentRepository repo) {
        this.repo = repo;
    }

    public List<Appointment> getAll() {
        return repo.findAll();
    }

    public Appointment create(Appointment appointment) {
        boolean exists = repo.existsByLocationAndDateAndTime(
            appointment.getLocation(),
            appointment.getDate(),
            appointment.getTime()
        );

        if (exists) {
            throw new RuntimeException("Time slot already booked");
        }

        return repo.save(appointment);
    }

    public void delete(Long id) {
        repo.deleteById(id);
    }
}
