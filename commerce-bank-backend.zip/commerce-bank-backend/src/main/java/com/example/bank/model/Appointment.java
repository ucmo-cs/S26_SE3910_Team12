package com.example.bank.model;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
public class Appointment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;

    private String location;
    private String topic;

    private LocalDate date;
    private LocalTime time;

    private String status = "scheduled";

    // Getters and Setters
}
