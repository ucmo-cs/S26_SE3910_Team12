package com.example.bank.repository;

import com.example.bank.model.Appointment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppointmentRepository extends JpaRepository<Appointment, Long> {
    boolean existsByLocationAndDateAndTime(String location, java.time.LocalDate date, java.time.LocalTime time);
}
