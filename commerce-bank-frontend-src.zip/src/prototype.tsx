import { useState } from "react";
import {
  CalendarDays,
  MapPin,
  User,
  Phone,
  Mail,
  Building2,
  CheckCircle2,
} from "lucide-react";

export default function Prototype() {
  const [formData, setFormData] = useState({
    location: "",
    topic: "",
    date: "",
    time: "",
    name: "",
    email: "",
    phone: "",
  });

  const [confirmed, setConfirmed] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const isFormComplete = Object.values(formData).every((value) => value !== "");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isFormComplete) setConfirmed(true);
  };

  const handleCancel = () => {
    setFormData({
      location: "",
      topic: "",
      date: "",
      time: "",
      name: "",
      email: "",
      phone: "",
    });
    setConfirmed(false);
  };

  const generateTimeSlots = () => {
    const times: string[] = [];
    const startHour = 9;
    const endHour = 17;

    for (let hour = startHour; hour < endHour; hour++) {
      for (let minutes = 0; minutes < 60; minutes += 15) {
        const formattedHour = hour.toString().padStart(2, "0");
        const formattedMinutes = minutes.toString().padStart(2, "0");
        times.push(`${formattedHour}:${formattedMinutes}`);
      }
    }

    return times;
  };

  return (
      <div className="min-h-screen bg-gray-100">

        {/* 🏦 HERO HEADER */}
        <div className="bg-gradient-to-r from-green-900 via-green-800 to-green-700 text-white">
          <div className="max-w-6xl mx-auto px-6 py-20">
            <div className="flex items-center gap-4 mb-6">
              <div className="bg-white/10 p-4 rounded-2xl backdrop-blur-sm">
                <Building2 size={36} />
              </div>
              <h1 className="text-4xl md:text-5xl font-bold tracking-tight">
                Commerce Bank
              </h1>
            </div>

            <h2 className="text-3xl md:text-4xl font-semibold mb-4">
              Schedule Your In-Branch Appointment
            </h2>

            <p className="text-lg md:text-xl text-green-100 max-w-2xl">
              Meet with a Commerce Bank specialist at a location near you.
              Choose your preferred branch, time, and topic — we’ll take care of the rest.
            </p>
          </div>
        </div>

        {/* 📋 FORM SECTION */}
        <div className="max-w-4xl mx-auto -mt-12 px-6 pb-20">
          <div className="bg-white shadow-2xl rounded-3xl p-8">

            {!confirmed ? (
                <form onSubmit={handleSubmit} className="space-y-6">

                  {/* Location */}
                  <div>
                    <label className="block font-semibold mb-2 flex items-center gap-2">
                      <MapPin size={18} /> Bank Location
                    </label>
                    <select
                        name="location"
                        value={formData.location}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    >
                      <option value="">Select a location</option>
                      <option>Downtown Branch</option>
                      <option>Westside Branch</option>
                      <option>Northside Branch</option>
                    </select>
                  </div>

                  {/* Topic */}
                  <div>
                    <label className="block font-semibold mb-2">
                      Appointment Topic
                    </label>
                    <select
                        name="topic"
                        value={formData.topic}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    >
                      <option value="">Select a topic</option>
                      <option>Open a New Account</option>
                      <option>Loan Consultation</option>
                      <option>Mortgage Discussion</option>
                      <option>Financial Planning</option>
                    </select>
                  </div>

                  {/* Date */}
                  <div>
                    <label className="block font-semibold mb-2 flex items-center gap-2">
                      <CalendarDays size={18} /> Select Date
                    </label>
                    <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    />
                  </div>

                  {/* Time */}
                  <div>
                    <label className="block font-semibold mb-2">
                      Select Time
                    </label>
                    <select
                        name="time"
                        value={formData.time}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    >
                      <option value="">Select a time</option>
                      {generateTimeSlots().map((time) => (
                          <option key={time} value={time}>
                            {time}
                          </option>
                      ))}
                    </select>
                  </div>

                  {/* Personal Info */}
                  <div>
                    <label className="block font-semibold mb-2 flex items-center gap-2">
                      <User size={18} /> Full Name
                    </label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold mb-2 flex items-center gap-2">
                      <Mail size={18} /> Email
                    </label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    />
                  </div>

                  <div>
                    <label className="block font-semibold mb-2 flex items-center gap-2">
                      <Phone size={18} /> Phone Number
                    </label>
                    <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full border rounded-xl p-3 focus:ring-2 focus:ring-green-600"
                    />
                  </div>

                  {/* Buttons */}
                  <div className="flex gap-4 pt-4">
                    <button
                        type="submit"
                        disabled={!isFormComplete}
                        className={`flex-1 py-3 rounded-xl font-semibold text-white transition ${
                            isFormComplete
                                ? "bg-green-700 hover:bg-green-800"
                                : "bg-gray-400 cursor-not-allowed"
                        }`}
                    >
                      Book Appointment
                    </button>

                    <button
                        type="button"
                        onClick={handleCancel}
                        className="flex-1 py-3 rounded-xl border border-gray-300 hover:bg-gray-100"
                    >
                      Cancel
                    </button>
                  </div>
                </form>
            ) : (
                /* ✅ CONFIRMATION SCREEN */
                <div className="text-center space-y-6 py-10">
                  <CheckCircle2 size={60} className="mx-auto text-green-600" />
                  <h3 className="text-2xl font-bold text-green-700">
                    Appointment Confirmed!
                  </h3>
                  <p className="text-gray-600">
                    {formData.name}, your appointment at the{" "}
                    <strong>{formData.location}</strong> for{" "}
                    <strong>{formData.topic}</strong> is scheduled on{" "}
                    <strong>{formData.date}</strong> at{" "}
                    <strong>{formData.time}</strong>.
                  </p>

                  <div className="flex gap-4 justify-center pt-4">
                    <button
                        onClick={() => setConfirmed(false)}
                        className="px-6 py-3 bg-green-700 text-white rounded-xl hover:bg-green-800"
                    >
                      Edit
                    </button>

                    <button
                        onClick={handleCancel}
                        className="px-6 py-3 border border-gray-300 rounded-xl hover:bg-gray-100"
                    >
                      Cancel Appointment
                    </button>
                  </div>
                </div>
            )}

          </div>
        </div>
      </div>
  );
}