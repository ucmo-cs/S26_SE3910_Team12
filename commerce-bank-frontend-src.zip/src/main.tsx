import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import Prototype from './prototype'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <Prototype />
  </StrictMode>,
)
